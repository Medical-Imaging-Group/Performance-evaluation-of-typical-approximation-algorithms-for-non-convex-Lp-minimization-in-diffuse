function [beta] = ITM(H, Ht, y, p,tol)

% Algorithm for solving Iterative Thresholding Method (ITM)
% tol - tolerance for convergence (default 1e-6)
% Algorithm for solving problems of the form:
% min ||x||_p s.t. ||y-Hx||_2 < err

% Inputs
% H - Forward Transform
% Ht - Backward Transform
% y - collected data
% p - non-convex norm
% normfac - highest singular value of A (default 1)
% err - two norm mismatch (default 1e-6)
% insweep - number of sweeps for internal loop (default 50)
% decfac - lambda decrease factor for outside loop (default 0.5)

% tol - tolerance for convergence

% copyright (c) Angshul Majumdar 2010 (Adapted from Majumdar's code to incorporate ITM)
 [r c]=size(H);
 
 
 %%%%%%This part (Preconditioning) is to ensure the maximum singular value is less than or
 %%%%%%equal to one. Note that this is esential for implementing ITM; see
 %%%%%%the manuscript for more details
lambda_pre=0.8;
         MJ11=zeros(r,r);
         [U S ~]=svd(H);
         MJ1=(S*S' + lambda_pre*eye(r,r));
          for ii=1:r
              MJ11(ii,ii)=(MJ1(ii,ii))^(-0.5);
          end

    MJ=MJ11*U';
% 
         H=MJ*H;
         y=MJ*y;
%%%%%%%%%%%%%%End of preconditioner%%%%%%%%%%%%%%%%%

if nargin < 4
    p = 1;
end
if nargin < 5
    tol = 1e-6;
end
err = 1e-6;


 insweep =60;
 decfac = 0.2;

[U S ~]=svd(H);
s=max(max(S));
 x_initial = H'*(y);
% x_initial=x;

x = x_initial;

lambdaInit =2;%decfac*max(abs(Ht*(y))); 
 lambda = lambdaInit;

f_current = norm(y-H*(x_initial))^2;%Calculate the residue 

while lambda > lambdaInit*tol

    for ins = 1:insweep
        f_previous = f_current;
        x = Threshold(x + (H'*(y - H*(x)))*s, s*lambda,p);%Update Equation


        f_current = norm(y-H*(x));% Calculate the residue
        
        if norm(f_current-f_previous)<tol % Terminate if the residue is less than prescribed tol
            break;
        end
    end
%     norm(y-H(x))
    if norm(y-H*(x))<err
        break;
    end
     lambda = decfac*lambda;
end
beta = x;

    function  z = Threshold(s1,thld,p)
          tau=thld^(1/(2-p))*(2-p)*(p/((1-p)^(1-p)))^(1/(2-p));
    
 theta0=thld^(1/(2-p))*(p*(1-p))^(1/(2-p));
in=find(s1(:)>tau);
  [r c]=size(s1);
  theta=theta0*ones(length(in),1);%%Theta0, lower bound where the root lies
  %Find the root using a simple-Newton-Ralphson method
  if length(in)>=1 % Make sure there is atleast one or more indices to find the root
   for i=1:10
  g_theta=theta+((thld*p).*(theta.^(p-1))) -(s1(in));%minimization function
  g_der=1+((thld*p*(p-1)).*(theta.^(p-2)));% derivative of the baove function for newton's scheme
  theta=theta-(g_theta./g_der);
   end
   s1(in)=theta;%Update the solution (this contains the computed roots)
 %Threshod criterion as per ITM
  end
   
     
 in=find(s1(:)<=tau);%Threshod criterion as per ITM
    length(in);
    s1(in)=0;
   z=s1;
 
    end
end