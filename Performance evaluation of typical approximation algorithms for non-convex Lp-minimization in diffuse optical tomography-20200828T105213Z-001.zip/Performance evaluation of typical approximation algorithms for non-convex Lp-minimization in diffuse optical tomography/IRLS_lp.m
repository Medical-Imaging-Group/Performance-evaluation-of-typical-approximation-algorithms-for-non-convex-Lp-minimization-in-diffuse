function [x] = IRLS_lp(A,y,p,lambda,x)
% Algorithm for solving Iteratively Reweighted Least Squares (IRLS)-minimization
%This code is similar to the one implemented in
%R. Chartrand, ``Exact reconstruction of sparse signals via non-convex minimization,'' 
%IEEE Sig. Proc. Letters {\bf 14}, 707--710 (2007).


% copyright (c) Calvin Shaw 2013 (contact: calvinshaw87@gmail.com for any bugs)
%IRLS code for Lp-minimization (||Ax-b||_2^2+\lambda||x||_p^p)
%Code written by Calvin---[11-06-2013]
r=(A*x-y);%Calculate the residue
[r n]=size(A);
el=0.1;
decfac=0.5;
maxit=16;
Tol=1e-6;
it=1;
Hess=A'*A;%Hessian matrix
val=100;
while (it<=maxit && val >=Tol)
dr=(x.*x + (el*(ones(n,1)))).^(1-(p/2));
reg=(p*lambda)./(dr);% Calculating iterative weights for solving the $Weighted L2-minimization problem$
% xp=x;
rp=r;
x=(Hess+diag(reg))\A'*y;% Solves the weighted Normal equation
r=(A*x-y);

val=norm(r-rp)^2;
% diff=sum(abs(data_diff.^2))
el=el*decfac;%decrease factor to get a decaying sequence
  lambda=lambda*decfac; %try reducing the lambda too, if results are not
% best
it=it+1
end

end

