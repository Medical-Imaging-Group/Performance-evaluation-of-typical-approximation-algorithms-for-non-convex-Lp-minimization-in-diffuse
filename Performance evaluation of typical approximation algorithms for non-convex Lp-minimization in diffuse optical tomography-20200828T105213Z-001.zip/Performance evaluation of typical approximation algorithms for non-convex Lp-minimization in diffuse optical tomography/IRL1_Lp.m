function [x] = IRL1_Lp(y, A, lambda, mu, Nit,p,Tol)

%Code modified by Calvin as part of the work presented in the manuscript
%"IRL1-minimization improves diffuse optical tomogrpahic imaging" Submitted
%to JBO, 2013 (For any bugs: contact: calvinshaw87@gmail.com)

% x = bpd_salsa_sparsemtx(y, A, lambda, mu, Nit)
%
% BASIS PURSUIT DENOISING
% Minimize ||y - A x||_2^2 + lambda * || x ||_1
% where A is a sparse matrix
%
% INPUT
%   y      : data
%   A      : sparse matrix
%   lambda : regularization parameter
%   mu     : ADMM parameter
%   Nit    : Number of iterations
%
% OUTPUT
%   x      : solution to BPD problem
%
% [x, cost] = bpd_salsa_sparsemtx(...) returns cost function history

% Ivan Selesnick
% NYU-Poly
% selesi@poly.edu
% March 2012

% The program is an original implementation of SALSA (Afonso, Bioucas-Dias, Figueiredo,
% IEEE Trans Image Proc, 2010, p. 2345)

[r n]=size(A);
el=1e-1;
decfac=0.5;%0.3->Case-1

l=1e-10; u=Inf;
if((l==-Inf)&&(u==Inf))
    project=@(x)x;
elseif (isfinite(l)&&(u==Inf))
    project=@(x)(((l<x).*x)+(l*(x<=l)));
elseif (isfinite(u)&&(l==-Inf))
     project=@(x)(((x<u).*x)+((x>=u)*u));
elseif ((isfinite(u)&&isfinite(l))&&(l<u))
    project=@(x)(((l<x)&(x<u)).*x)+((x>=u)*u)+(l*(x<=l));
else
    error('lower and upper bound l,u should satisfy l<u');
end

   

ATy = A'*y;
x = ATy;
d = zeros(size(x));

[M, N] = size(A);

F = A'*A + mu*speye(N);
r=(A*x-y);%Calculate the residue
% F=(Hess + mu.*eye(size(B(1:l_step,1:l_step+1),2)));
issparse(F)
val=100;%initial value to enter the loop
it=1;
while (it<=Nit && val >=Tol)
    rp=r;

    dr=(abs(x)).^(1-(p));
w=(p)./(dr);%Compute the weights (as per Eq.7 in the manuscript)
    u = soft(x + d, 0.5*w.*lambda/mu) - d;

     x = F \ (ATy + mu*u);
%          x=project(x);% Uncomment this for non-negative constraint
    d = x - u;
    r=(A*x-y); 
   val=norm(r-rp)^2;%Calculate the norm of the residue for the stopping criterion
     

     el=el*decfac;
     it=it+1;
%  lambda=decfac*lambda;
end
